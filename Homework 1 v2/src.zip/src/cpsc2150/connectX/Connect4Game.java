// Ben Joye
// CPSC-2150
// 9/23/18

package cpsc2150.connectX;

import java.util.Scanner;

public class Connect4Game {
    /**
     * @invariant:
     *  0 <= col < 7
     */
    public static void main(String [] args) {

        char again = 'Y';

        while (again == 'Y' || again == 'y') {

            GameBoard board = new GameBoard();
            boolean gameWon = false;
            boolean free;
            Scanner scanner = new Scanner(System.in);
            char player = 'O';
            int col;
            System.out.println(board.toString());

            while (!gameWon) {

                if (player == 'X')
                    player = 'O';
                else
                    player = 'X';

                System.out.println("Player " + player + ", what column do you want to place your marker in?");
                col = scanner.nextInt();

                if (col < 0 || col > 6) {
                    while (col < 0 || col > 6) {

                        if (col < 0) {
                            System.out.println("Column cannot be less that 0");
                        } else if (col > 6) {
                            System.out.println("Column cannot be greater than 6");
                        }
                        System.out.println("Player " + player + ", what column do you want to place your marker in?");
                        col = scanner.nextInt();
                    }
                }

                free = board.checkIfFree(col);
                if (free == true) {
                    board.placeToken(player, col);
                } else {
                    while (!board.checkIfFree(col)) {
                        System.out.println("Column is full");
                        System.out.println("Player " + player + ", what column do you want to place your marker in?");
                        col = scanner.nextInt();
                    }
                    board.placeToken(player, col);
                }

                System.out.println(board.toString());
                gameWon = board.checkForWin(col);
            }

            if (board.checkTie()) {
                System.out.println("The game is a tie!");
            } else {
                System.out.println("Player " + player + " Won!");
            }
            System.out.println("Would you like to play again? Y/N");
            again = scanner.next().charAt(0);
        }
    }
}