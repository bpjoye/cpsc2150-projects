package cpsc2150.MyQueue;

/**
 * A queue containing integers.
 * A queue is a data structure where the first item added to the structure is the first item removed from the structure
 * This queue is bounded by MAX_DEPTH
 *
 * Initialization ensures the queue is empty
 * Defines: size:Z
 * Constraints: 0 <= size <= MAX_DEPTH
 */
public interface IntegerQueueI {

    int MAX_DEPTH = 100;

    /**
     * Adds x to the end of the Queue
     * @param x: int to add
     * @pre: x is an int
     * @post: x will be at the end of the list, depth++
     */
    public void add(Integer x);

    /**
     * Removes and returns the Integer at the front of the queue
     * @return: the first integer in the list
     * @pre: depth > 0
     * @post: depth--, the first element will be removed
     */
    public Integer pop();

    //

    /**
     * Returns the number of Integers in the Queue
     * @return: the number of Integers in the Queue
     * @pre: depth > 0
     * @post: will return the size of the list
     */
    public int size();
}
